#Author
Franck Canonne
franck.canonne@gmail.com
https://factotum.bzh

## Getting Started

Ce projet montre comment utiliser une base de données MySQL dans une application Flutter avec PHP et JSON.


