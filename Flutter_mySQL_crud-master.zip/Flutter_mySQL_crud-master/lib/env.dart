class Env {
  static String URL_PREFIX = "https://sql.qr.bzh/crud/api";
}